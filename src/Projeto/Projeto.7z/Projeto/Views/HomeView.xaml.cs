﻿using Projeto.ViewModels;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Projeto.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class HomeView : ContentPage
	{
        public HomeViewModel ViewModel { get; set; }

        public HomeView ()
		{
			InitializeComponent ();
            BindingContext = (ViewModel = new HomeViewModel());
		}

        protected async override void OnAppearing()
        {
            base.OnAppearing();

            await ViewModel.ObterCatalogo();
        }
    }
}