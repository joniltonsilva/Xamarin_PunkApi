﻿using BottomBar.XamarinForms;
using Xamarin.Forms;

namespace Projeto
{
    public partial class MainPage : BottomBarPage
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
