﻿namespace Projeto
{
    public static class AppSettings
    {
        public const string API_URL = "https://api.punkapi.com/v2/beers";
    }
}
