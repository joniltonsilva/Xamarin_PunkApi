﻿using Projeto.Models;
using Projeto.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using System.Linq;
using Xamarin.Forms.Extended;

namespace Projeto.ViewModels
{
    public class HomeViewModel : BaseViewModel
    {
        private readonly IApiService _apiService;

        public InfiniteScrollCollection<CatalogoItemParaLista> Catalogo { get; }
        private const int PageSize = 20;
        public HomeViewModel()
        {
            _apiService = DependencyService.Get<IApiService>();
            Catalogo = new InfiniteScrollCollection<CatalogoItemParaLista>
            {
                OnLoadMore = async () =>
                {                    
                    var page = Catalogo.Count / PageSize;
                    var items = await Buscar(page + 1, PageSize);
        
                    return items;
                }
            };
        }

        public async Task ObterCatalogo()
        {
            await Catalogo.LoadMoreAsync();
        }

        private async Task<List<CatalogoItemParaLista>> Buscar(int pagina, int itemsPorPagina)
        {
            List<CatalogoItemParaLista> catalogoItems = null;
            IsBusy = true;
            try
            {
                catalogoItems = await _apiService.GetAsync<List<CatalogoItemParaLista>>(AppSettings.API_URL + $"?page={pagina}&per_page={itemsPorPagina}");           
            }
            catch (Exception ex)
            {

            }
            finally
            {
                IsBusy = false;
            }

            return catalogoItems;
        }
    }
}
